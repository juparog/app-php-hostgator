<html>
<head>
<title>Witsoft PHP Test</title>
</head>
<body>
<?php echo '<p>Hello World Witsoft!!</p>'; ?>
<a href="./component/greet.php">Greet</a>
</body>
</html>
