<html>
<head>
<title>Hello Witsoft</title>
</head>
<body>
<?php echo '<h1>Hello Witsoft!!</p>'; ?>
</body>
</html>
